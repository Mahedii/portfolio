<script>
    export default {
    }
</script>

<template>
    <h1>About PAGE</h1>
</template>