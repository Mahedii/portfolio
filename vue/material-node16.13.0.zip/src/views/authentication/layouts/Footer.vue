<script>
    export default {
    }
</script>

<template>
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-center">
                        <p class="mb-0 text-muted">&copy;
                            {{new Date().getFullYear()}} © Velzon. Crafted with 
                            <i class="mdi mdi-heart text-danger"></i>  by Themesbrand
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</template>

<style>
</style>