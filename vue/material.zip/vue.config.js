module.exports = {
    transpileDependencies: ["@vueform"]
}